window = {};

exports.forDeps = function () {};
