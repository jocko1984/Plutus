/*eslint-env node*/
import './static/css/main.css';
import './src/Main.purs';
