"use strict";

exports.marloweRunLogo = require("static/images/marlowe-run-logo.svg");

exports.marloweRunNavLogo = require("static/images/marlowe-run-nav-logo.svg");

exports.marloweRunNavLogoDark = require("static/images/marlowe-run-nav-logo-dark.svg");

exports.backgroundShape = require("static/images/background-shape.svg");

exports.arrowBack = require("static/images/arrow-back.svg");

exports.linkHighlight = require("static/images/link-highlight.svg");

exports.getStartedThumbnail = require("static/images/get-started-thumbnail.jpg")

exports.cfdIcon = require("static/images/cfd-icon.svg")

exports.loanIcon = require("static/images/loan-icon.svg")

exports.purchaseIcon = require("static/images/purchase-icon.svg")
