.. _plutus_getting_started:

How to get started with the Plutus Platform
===========================================

We provide a `template repository <https://github.com/input-output-hk/plutus-starter>`_ that you can use to get started quickly.
The repository `README` provides up-to-date instructions for how to set it up.


Further reading
---------------

This would be a good time to try one of the :ref:`tutorials <plutus_tutorials>`.
