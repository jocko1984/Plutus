.. _plutus_tutorials:

Tutorials
=========

.. toctree::
   :maxdepth: 3
   :titlesonly:

   plutus-playground
   basic-apps
   plutus-tx
   basic-validators
   basic-minting-policies
   contract-testing
