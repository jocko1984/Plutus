.. _bibliography:

Bibliography
============

.. bibliography:: ../bibliography.bib
