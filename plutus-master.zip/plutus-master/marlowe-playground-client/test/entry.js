
import '../grammar.ne';

import {main} from './Main.purs';

main();
