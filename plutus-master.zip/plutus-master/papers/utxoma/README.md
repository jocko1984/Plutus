# Plain Multicurrency

This paper adds native multicurrency features to the basic UTxO ledger model.

To appear at [ISoLA 2020](http://isola-conference.org/isola2020/).
