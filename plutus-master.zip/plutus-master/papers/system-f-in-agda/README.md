Paper on Agda formalisation of Plutus Core.

------

This has now appeared at [MPC2019](https://www.cs.nott.ac.uk/~pszgmh/mpc19.html).  The
publisher's page for the proceedings is [here](https://www.palgrave.com/gp/book/9783030336356).

DOI for proceedings: https://doi.org/10.1007/978-3-030-33636-3

DOI for paper: https://doi.org/10.1007/978-3-030-33636-3_10
