## Cost model notes

Some notes on cost models and benchmarking results.  See
[sample.R](./sample.R) for an example of how to plot the graphs
appearing in the document.