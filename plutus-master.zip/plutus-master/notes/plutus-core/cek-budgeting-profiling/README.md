## CEK budgeting and profiling

Profiling and resource budgeting overhead in the CEK machine: see [CekProfiling.md](./CekProfiling.md). 