pdf ("loop-times.pdf")
source ("r/loop-plot.r")
dev.off()

pdf ("loop-mem.pdf")
source ("r/loop-mem-plot.r")
dev.off()

pdf ("tri-times.pdf")
source ("r/tri-plot.r")
dev.off()

pdf ("tri-mem.pdf")
source ("r/tri-mem-plot.r")
dev.off()

pdf ("fib-times.pdf")
source ("r/fib-plot.r")
dev.off()

pdf ("fib-mem.pdf")
source ("r/fib-mem-plot.r")
dev.off()

pdf ("fac-times.pdf")
source ("r/fac-plot.r")
dev.off()

pdf ("fac-mem.pdf")
source ("r/fac-mem-plot.r")
dev.off()


