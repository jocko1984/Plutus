pdf ("Loop-times.pdf")
source ("r/Loop-plot.r")
dev.off()

pdf ("Loop-mem.pdf")
source ("r/Loop-mem-plot.r")
dev.off()

pdf ("Tri-times.pdf")
source ("r/Tri-plot.r")
dev.off()

pdf ("Tri-mem.pdf")
source ("r/Tri-mem-plot.r")
dev.off()

pdf ("Fib-times.pdf")
source ("r/Fib-plot.r")
dev.off()

pdf ("Fib-mem.pdf")
source ("r/Fib-mem-plot.r")
dev.off()

pdf ("Fac-times.pdf")
source ("r/Fac-plot.r")
dev.off()

pdf ("Fac-mem.pdf")
source ("r/Fac-mem-plot.r")
dev.off()


